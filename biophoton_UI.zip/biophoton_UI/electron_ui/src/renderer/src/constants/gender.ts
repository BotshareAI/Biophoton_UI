export const gender = [
  { id: '1', name: 'Male' },
  { id: '2', name: 'Female' },
  { id: '3', name: 'Non-Binary' }
]

export const mappedGender = {
  1: 'Male',
  2: 'Female',
  3: 'Non-Binary'
}
