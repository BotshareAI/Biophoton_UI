// eslint-disable-next-line @typescript-eslint/no-explicit-any
export const BandageIcon = ({ fill, style }: { fill: string; style: any }): React.JSX.Element => (
  <svg version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 122.88 122.88" style={style}>
    <g fill="none" stroke={fill} strokeWidth="4">
      <path
        d="M3.52,16.22l12.7-12.7c4.69-4.69,12.37-4.69,17.07,0l86.07,86.07c4.69,4.69,4.69,12.37,0,17.07
        l-12.7,12.7c-4.69,4.69-12.37,4.69-17.07,0L3.52,33.29C-1.17,28.59-1.17,20.91,3.52,16.22z"
      />

      <circle cx="85.24" cy="94.27" r="2.5" />

      <rect x="50" y="40" width="30" height="30" transform="rotate(45 55 55)" />

      <circle cx="29.71" cy="37.5" r="2.5" />
      <circle cx="20.6" cy="28.6" r="2.5" />
      <circle cx="37.5" cy="28.3" r="2.5" />
      <circle cx="29.3" cy="18.9" r="2.5" />

      <circle cx="95.63" cy="104.3" r="2.5" />
      <circle cx="103.9" cy="94.3" r="2.5" />
      <circle cx="95.2" cy="84.3" r="2.5" />
    </g>
  </svg>
)
