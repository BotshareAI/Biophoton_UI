export type Subcategory = { id: number; name: string; category_id: number }
