export type Meridian = { id: number; name: string }

export type MeridianSelect = { value: string; label: string }
