# License – Private and Confidential

This project and all associated code, documentation, designs, and results are the exclusive property of the Botshare Sp. z  OO (here and further Client).

## Ownership
All intellectual property rights, including source code, documentation, hardware designs, and data generated during the course of development, are fully owned by the Client.

## Confidentiality
This project is strictly confidential. No part of this codebase or its contents may be:

- Copied
- Redistributed
- Published
- Used in other projects

without prior written consent from the Client.

## Restrictions
This is **not an open-source project**. Use is restricted solely to the Client and its authorized representatives.

Any unauthorized access, distribution, or use constitutes a violation of this license and may result in legal action.

---

**© [2025] [Botshare Sp. z OO]. All rights reserved.**
