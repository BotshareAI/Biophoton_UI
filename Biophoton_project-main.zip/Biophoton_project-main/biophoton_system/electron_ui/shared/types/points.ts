export type Points = {
  lh: number[]
  rh: number[]
  lf: number[]
  rf: number[]
}
