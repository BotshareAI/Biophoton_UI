export const categories = [
  { id: 1, name: 'Nosodes' },
  { id: 2, name: 'Support' },
  { id: 3, name: 'Allersode' }
]
